#pragma once
#include <string>
#include <iostream>
/*
enum Operations
{
eval, poly, mul, add, comp, log, del, help, exit

};
*/

const std::string EVALUATE = "eval";
const std::string POLYNOM = "poly";
const std::string MULTIPLY = "mul";
const std::string ADD = "add";
const std::string COMPOSITE = "comp";
const std::string LOG = "log";
const std::string DELETE = "del";
const std::string HELP = "help";
const std::string EXIT = "exit";
