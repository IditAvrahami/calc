#include "Menu.h"

int main()
{
	Menu a;
	a.start();
	
	return 0;
}